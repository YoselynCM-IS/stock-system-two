<li class="nav-item dropdown">
	<a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
		Cortes <span class="caret"></span>
	</a>
	<div class="dropdown-menu dropdown-menu-left" aria-labelledby="navbarDropdown">
		<a class="dropdown-item" href="<?php echo e(route('manager.cortes.lista')); ?>">
			<?php echo e(__("Lista")); ?>

		</a>
		<a class="dropdown-item" href="<?php echo e(route('manager.cortes.pagos')); ?>">
			<?php echo e(__("Pagos")); ?>

		</a>
		<a class="dropdown-item" href="<?php echo e(route('information.remisiones.lista')); ?>">
			<?php echo e(__('Remisiones')); ?>

		</a>
		<a class="dropdown-item" href="<?php echo e(route('manager.remisiones.pago_devolucion')); ?>">
			<?php echo e(__('Devoluciones / Cerrar')); ?>

		</a>
		<a class="dropdown-item" href="<?php echo e(route('historial.remisiones.lista', 0)); ?>">
			<?php echo e(__("Historial")); ?>

		</a>
	</div>
</li>
<li class="nav-item dropdown">
	<a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
		Entradas <span class="caret"></span>
	</a>
	<div class="dropdown-menu dropdown-menu-left" aria-labelledby="navbarDropdown">
		<a class="dropdown-item" href="<?php echo e(route('manager.entradas.lista')); ?>">
			<?php echo e(__("Lista")); ?>

		</a>
		<a class="dropdown-item" href="<?php echo e(route('manager.entradas.pagos')); ?>">
			<?php echo e(__("Pagos")); ?>

		</a>
	</div>
</li>
<li class="nav-item dropdown">
	<a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
		Libros <span class="caret"></span>
	</a>
	<div class="dropdown-menu dropdown-menu-left" aria-labelledby="navbarDropdown">
		<a class="dropdown-item" href="<?php echo e(route('manager.libros')); ?>"><?php echo e(__("Lista")); ?></a>
		<a class="dropdown-item" href="<?php echo e(route('manager.codes')); ?>"><?php echo e(__("Códigos")); ?></a>
	</div>
</li>
<li>
	<a class="nav-link" href="<?php echo e(route('manager.clientes')); ?>"><?php echo e(__("Clientes")); ?></a>
</li>
<li class="nav-item dropdown">
	<a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
		Pedidos <span class="caret"></span>
	</a>
	<div class="dropdown-menu dropdown-menu-left" aria-labelledby="navbarDropdown">
		<a class="dropdown-item" href="<?php echo e(route('information.pedidos.cliente')); ?>"><?php echo e(__("Cliente")); ?></a>
		<a class="dropdown-item" href="<?php echo e(route('information.pedidos.proveedor')); ?>"><?php echo e(__("Proveedor")); ?></a>
	</div>
</li>
<li class="nav-item dropdown">
	<a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
		Información <span class="caret"></span>
	</a>
	<div class="dropdown-menu dropdown-menu-left" aria-labelledby="navbarDropdown">
		<a class="dropdown-item" href="<?php echo e(route('information.actividades.lista')); ?>">
			<?php echo e(__("Actividades")); ?>

		</a>
		<a class="dropdown-item" href="<?php echo e(route('information.reportes.lista')); ?>">
			<?php echo e(__("Reportes")); ?>

		</a>
	</div>
</li>
<li class="nav-item dropdown">
	<a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
		Otros <span class="caret"></span>
	</a>
	<div class="dropdown-menu dropdown-menu-left" aria-labelledby="navbarDropdown">
		<a class="dropdown-item" href="<?php echo e(route('manager.otros.promociones')); ?>"><?php echo e(__("Promociones")); ?></a>
		<a class="dropdown-item" href="<?php echo e(route('manager.otros.donaciones')); ?>"><?php echo e(__("Donaciones")); ?></a>
		<a class="dropdown-item" href="<?php echo e(route('manager.salidas')); ?>"><?php echo e(__("Salidas")); ?></a>
		<a class="dropdown-item" href="<?php echo e(route('manager.otros.notas')); ?>"><?php echo e(__("Notas")); ?></a>
	</div>
</li>
<li class="nav-item dropdown">
	<a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
		Movimientos <span class="caret"></span>
	</a>
	<div class="dropdown-menu dropdown-menu-left" aria-labelledby="navbarDropdown">
		<a class="dropdown-item" href="<?php echo e(route('manager.movimientos.clientes')); ?>">
			<?php echo e(__("Clientes")); ?>

		</a>
		<a class="dropdown-item" href="<?php echo e(route('manager.movimientos.libros')); ?>">
			<?php echo e(__("Libros")); ?>

		</a>
		<a class="dropdown-item" href="<?php echo e(route('manager.movimientos.entradas-salidas')); ?>">
			<?php echo e(__("Entradas / Salidas")); ?>

		</a>
		<a class="dropdown-item" href="<?php echo e(route('manager.remisiones.fecha_adeudo')); ?>">
			<?php echo e(__('Fecha de adeudos')); ?>

		</a>
	</div>
</li>
<user-notifications :user_id="<?php echo e(auth()->user()->id); ?>" :noleidos="<?php echo e(Auth::user()->unreadNotifications); ?>"></user-notifications>
<?php if(env('APP_NAME') == 'MAJESTIC EDUCATION'): ?>
	<li>
		<a class="nav-link" href="https://mestockexterno.com/login" target="_blank"><?php echo e(__("Querétaro")); ?></a>
	</li>
<?php endif; ?>	
<li>
	<a class="nav-link" href="<?php echo e(route('manager.users.lista')); ?>"><?php echo e(__("Usuarios")); ?></a>
</li>
<?php echo $__env->make('partials.navigations.logged', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PRUEBAS\STOCK-VERSION-8\resources\views/partials/navigations/Manager.blade.php ENDPATH**/ ?>