@extends('layouts.app')

@section('content')
    <unidades-libro-component></unidades-libro-component>
@endsection