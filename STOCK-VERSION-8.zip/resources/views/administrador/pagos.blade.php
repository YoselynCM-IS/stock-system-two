@extends('layouts.app')

@section('content')
    <!-- <pagos-component :role_id="{{auth()->user()->role_id}}"></pagos-component> -->
    <lista-pagos-component></lista-pagos-component>
@endsection