@extends('layouts.app')

@section('content')
    <movmonto-component :editoriales="{{$editoriales}}"></movmonto-component>
@endsection