@extends('layouts.app')

@section('content')
    <fecha-adeudo-component></fecha-adeudo-component>
@endsection