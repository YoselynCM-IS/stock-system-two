@extends('layouts.app')

@section('content')
    <movunidades-component :editoriales="{{$editoriales}}"></movunidades-component>
@endsection