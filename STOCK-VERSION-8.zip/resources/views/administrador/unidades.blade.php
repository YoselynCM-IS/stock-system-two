@extends('layouts.app')

@section('content')
    <unidades-component></unidades-component>
@endsection