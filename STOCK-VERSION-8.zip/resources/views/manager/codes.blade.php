@extends('layouts.app')

@section('content')
    <codes-component></codes-component>
@endsection