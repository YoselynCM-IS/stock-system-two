@extends('layouts.app')

@section('content')
    <lista-pagos-component></lista-pagos-component>
@endsection