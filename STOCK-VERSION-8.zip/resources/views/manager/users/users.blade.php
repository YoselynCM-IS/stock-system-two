@extends('layouts.app')

@section('content')
    <list-users-component></list-users-component>
@endsection