@extends('layouts.app')

@section('content')
    <mov-clientes-component></mov-clientes-component>
@endsection