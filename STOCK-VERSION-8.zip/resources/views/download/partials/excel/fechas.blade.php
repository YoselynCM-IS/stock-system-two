<label><b>Fecha: {{ $fecha }}</b> </label><br>
@if($final != '0000-00-00')
    <label><b>De:</b> {{ $inicio }} - <b>A:</b> {{ $final }}</label><br>
@endif