@extends('layouts.app-simple')

@section('content')
    <div class="text-center">
        <h5>MAJESTIC EDUCATION - Querétaro</h5>
    </div>
    <b-embed type="iframe" allowfullscreen
        src="https://stock-control-2-me.herokuapp.com/login"
    ></b-embed>
@endsection