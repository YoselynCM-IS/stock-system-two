@extends('layouts.app')

@section('content')
    <all-libros-component></all-libros-component>
@endsection