@extends('layouts.app')

@section('content')
    <pagos-remisiones></pagos-remisiones>
@endsection