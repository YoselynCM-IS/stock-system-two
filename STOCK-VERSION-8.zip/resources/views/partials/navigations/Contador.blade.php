<li>
	<a class="nav-link" href="{{ route('information.remisiones.lista') }}">{{ __("Remisiones") }}</a>
</li>
<li>
	<a class="nav-link" href="{{ route('contador.movimientos_monto') }}">{{ __("Movimientos") }}</a>
</li>
@include('partials.navigations.logged')