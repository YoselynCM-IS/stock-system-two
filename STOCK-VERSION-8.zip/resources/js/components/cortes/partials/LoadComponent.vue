<template>
    <div>
        <div class="text-center text-info my-2 mt-3">
            <b-spinner class="align-middle"></b-spinner>
            <strong>Cargando...</strong>
        </div>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>