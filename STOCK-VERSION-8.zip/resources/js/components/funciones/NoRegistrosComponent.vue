<template>
    <div>
        <b-alert show variant="secondary">
            <i class="fa fa-warning"></i> No se encontraron registros.
        </b-alert>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>